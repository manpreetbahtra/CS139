from flask import Flask, render_template
app = Flask(__name__)

#route to the index
@app.route('/')
def index():
    return render_template('index.html')
#route to the register
@app.route('/register')
def register():
    return render_template('register.html')
#route to the login
@app.route('/login')
def login():
    return render_template('login.html')
#route to the allLists
@app.route('/allLists')
def allLists():
    return render_template('allLists.html')
#route to the List 1
@app.route('/list1')
def list1():
    return render_template('list1.html')








