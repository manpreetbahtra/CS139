from flask_login import LoginManager, login_user, current_user, logout_user, login_required
import os
from markupsafe import escape, Markup


# import SQLAlchemy
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError

# create the Flask app
from flask import Flask, render_template, request, session, redirect
app = Flask(__name__)

# select the database filename
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///todo.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# set up a 'model' for the data you want to store
from db_schema import db, UserObject, List, ListItem, dbinit

# init the database so it can connect with our app
db.init_app(app)
login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.login_message_category = "info"

# change this to False to avoid resetting the database every time this app is restarted
resetdb = True
if resetdb:
    with app.app_context():
        SECRET_KEY = os.urandom(32)
        app.config["SECRET_KEY"] = SECRET_KEY
        login_manager.init_app(app)
        # drop everything, create all the tables, then put some data into the tables
        # db.drop_all()
        db.create_all()
        # dbinit()

@login_manager.user_loader
def load_user(user_id):
    try:
        return UserObject.getUser(user_id)
    except:
        return None

#route to the home page of user 
@app.route('/', methods = ["POST", "GET"])
@login_required
def index():
    if request.method == "POST":
        items = request.form["item"]
        safe_string = Markup(items).striptags()
        List.createListItem(safe_string, session['userid'])
        print("added")
    lists = List.query.filter_by(user_id=session["userid"]).all()
    rows = List.query.all()
    return render_template('index2.html', lists=lists)

#route to the register
@app.route('/register', methods = ["POST", "GET"])
def register():
    if current_user.is_authenticated:
        return redirect('/')
        
    if request.method=="POST":
        name = request.form["name"]
        username = request.form["username"]
        password = request.form["user_password"]
        user = UserObject.createUser(name, username, password)
        session['userid'] = user.id
        login_user(user) 
        return redirect('/')
    return render_template('register.html')

#route to the login
@app.route('/login', methods = ["POST", "GET"])
def login():
    if current_user.is_authenticated:
        return redirect('/')

    if request.method=="POST":
        username = request.form["username"]
        password = request.form["user_password"]

        user = UserObject.loginUser(username, password)
        if user: 
            login_user(user)
            session['userid'] = user.id
            return redirect('/')
    return render_template('login.html')

#route to logout
@app.route('/logout')
@login_required
def logout():
    logout_user()
    # safe_string = escape (password)
    print('logout')
    return redirect('/login')

