from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

# create the database interface
db = SQLAlchemy()

# a model of a user for the database
class User(db.Model):
    __tablename__='users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), unique=False)
    username = db.Column(db.String(20), unique=True)
    password_hash = db.Column(db.String(25), unique=False, nullable=False)
    lists = db.relationship('List', backref='users', lazy=True)
    def __init__(self, name, username, password_hash):  
        self.name = name
        self.username = username
        self.password_hash = password_hash


class UserObject():
    allUsers={}
    def __init__(self, id, name, username, password_hash):  
        self.id = id
        self.name = name
        self.username = username
        self.password_hash = password_hash
        self.is_authenticated = True
        self.is_active = True
        self.is_anonymous = False

    def get_id(self):
        return self.id

    @staticmethod
    def createUser(name, username, password):
        password_hash = generate_password_hash(password)
        userRecord = User(
            name = name,
            username = username,
            password_hash = password_hash
        ) 
        db.session.add(userRecord)
        db.session.commit()
        user = UserObject(userRecord.id, name, username, password_hash)
        UserObject.allUsers[userRecord.id] = user 
        return user  
    
    @staticmethod
    def loginUser(username, password):
        userRecord = User.query.filter_by(username=username).first()

        if not userRecord:
            return None
        #print(user)
        isValid = check_password_hash(userRecord.password_hash, password)
        if isValid:
            user = UserObject(userRecord.id, userRecord.name, userRecord.username, userRecord.password_hash)
            UserObject.allUsers[userRecord.id] = user
            return user

    @staticmethod
    def getUser(id):
        return UserObject.allUsers[id]

# a model of a list for the database
# it refers to a user
class List(db.Model):
    # __tablename__='lists'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text()) #name of the list item
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)  # this ought to be a "foreign key"
    items = db.relationship('ListItem', backref='list', lazy=True)

    def __init__(self, name, user_id):
        self.name=name
        self.user_id = user_id
    
    def createListItem(item, user_id):
        listItem = List (
            name = item,
            user_id = user_id
        )
        db.session.add(listItem)
        db.session.commit()
        return listItem

# a model of a list item for the database
# it refers to a list
class ListItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text())
    list_id = db.Column(db.Integer, db.ForeignKey('list.id'), nullable=False)  # this ought to be a "foreign key"

    def __init__(self, name, list_id):
        self.name=name
        self.list_id=list_id

# put some data into the tables
def dbinit():
    user_list = [
        User("Felicia", "fel", "12345"), 
        User("Petra", "petra123", "4567")
        ]
    db.session.add_all(user_list)
    db.session.commit()

    # find the id of the user Felicia
    felicia_id = User.query.filter_by(username="Felicia").first().id

    all_lists = [
        List("Shopping",felicia_id), 
        List("Chores",felicia_id)
        ]
    db.session.add_all(all_lists)
    db.session.commit()

    # find the ids of the lists Chores and Shopping

    chores_id = List.query.filter_by(name="Chores").first().id
    shopping_id= List.query.filter_by(name="Shopping").first().id

    all_items = [
        ListItem("Potatoes",shopping_id), 
        ListItem("Shampoo", shopping_id),
        ListItem("Wash up",chores_id), 
        ListItem("Vacuum bedroom",chores_id)
        ]
    db.session.add_all(all_items)

    # commit all the changes to the database file
    db.session.commit()

def selectLists():
    List.query.filter()
